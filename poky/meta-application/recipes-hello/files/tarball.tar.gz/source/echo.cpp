#include "echo.h"
#include <iostream>

void hello_world() {
	std::cout << "Hello World !" << std::endl;
}
