#include "echo.h"

int main() {
	hello_world();
	return 0;
}
