#ifndef ECHO_H
#define ECHO_H

void hello_world();

#endif // ECHO_H
